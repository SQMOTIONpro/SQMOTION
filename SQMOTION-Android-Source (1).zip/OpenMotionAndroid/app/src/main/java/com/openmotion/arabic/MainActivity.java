package com.openmotion.arabic;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MainActivity extends Activity {
    private static final String TAG = "SQMOTION";
    private static final int FILE_PICKER_REQUEST = 6124;
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String BLOB_DOWNLOAD_HOOK = """
        (function(){
          if(window.__sqmotionAndroidDownloadsInstalled)return;
          window.__sqmotionAndroidDownloadsInstalled=true;
          const readChunk=blob=>new Promise((resolve,reject)=>{
            const reader=new FileReader();
            reader.onload=()=>resolve(String(reader.result||'').split(',')[1]||'');
            reader.onerror=()=>reject(reader.error||new Error('Could not read export chunk'));
            reader.readAsDataURL(blob);
          });
          document.addEventListener('click',async function(event){
            const link=event.target&&event.target.closest?event.target.closest('a[download]'):null;
            if(!link||!String(link.href||'').startsWith('blob:'))return;
            event.preventDefault();event.stopImmediatePropagation();
            let token='';
            try{
              const blob=await fetch(link.href).then(response=>{if(!response.ok)throw new Error('Export could not be read');return response.blob()});
              token=window.SQMOTIONNativeDownloads.beginDownload(link.download||'SQMOTION-export.bin');
              if(!token)throw new Error('Could not create download file');
              const chunkSize=1024*1024;
              for(let offset=0;offset<blob.size;offset+=chunkSize){
                const encoded=await readChunk(blob.slice(offset,Math.min(offset+chunkSize,blob.size)));
                if(!window.SQMOTIONNativeDownloads.writeChunk(token,encoded))throw new Error('Could not write export chunk');
              }
              if(!window.SQMOTIONNativeDownloads.finishDownload(token,blob.type||'application/octet-stream'))throw new Error('Could not finish export');
              token='';
            }catch(error){
              if(token)window.SQMOTIONNativeDownloads.cancelDownload(token);
              console.error('[SQMOTION Android] export failed',error);
              alert('تعذّر حفظ الملف. جرّب تصديره مرة أخرى.');
            }
          },true);
        })();
        """;

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 18, 29));
        getWindow().setNavigationBarColor(Color.rgb(16, 18, 29));

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        webView.addJavascriptInterface(new NativeDownloads(), "SQMOTIONNativeDownloads");

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Uri uri = Uri.parse(url);
                if (APP_HOST.equalsIgnoreCase(uri.getHost())) view.evaluateJavascript(BLOB_DOWNLOAD_HOOK, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (APP_HOST.equalsIgnoreCase(uri.getHost())) return false;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception e) { Log.w(TAG, "No browser available", e); }
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*", "audio/*", "application/json", "text/xml", "application/zip", "application/x-zip-compressed", "application/octet-stream", "model/gltf-binary", "model/gltf+json", "model/obj", "model/stl", "text/plain", "font/ttf", "font/otf", "font/woff", "font/woff2"});
                try { startActivityForResult(intent, FILE_PICKER_REQUEST); }
                catch (Exception e) {
                    pendingFileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "تعذّر فتح منتقي الملفات", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d(TAG, message.message() + " (" + message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
        });

        webView.loadUrl(APP_URL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST || pendingFileCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        pendingFileCallback.onReceiveValue(results);
        pendingFileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("SQMOTIONNativeDownloads");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class NativeDownloads {
        private final ConcurrentHashMap<String, File> pending = new ConcurrentHashMap<>();

        @JavascriptInterface
        public String beginDownload(String suggestedName) {
            try {
                String safe = suggestedName == null ? "SQMOTION-export.bin" : suggestedName;
                safe = safe.replaceAll("[/\\\\:*?\"<>|]", "_").replaceAll("[\\r\\n]", "_");
                if (safe.trim().isEmpty()) safe = "SQMOTION-export.bin";
                String token = UUID.randomUUID().toString() + "|" + safe;
                File file = new File(getCacheDir(), "om-export-" + UUID.randomUUID());
                if (!file.createNewFile()) return "";
                pending.put(token, file);
                return token;
            } catch (Exception e) {
                Log.e(TAG, "Cannot start export", e);
                return "";
            }
        }

        @JavascriptInterface
        public boolean writeChunk(String token, String base64Chunk) {
            try {
                File file = pending.get(token);
                if (file == null || base64Chunk == null) return false;
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                try (FileOutputStream out = new FileOutputStream(file, true)) { out.write(bytes); }
                return true;
            } catch (Exception e) {
                Log.e(TAG, "Cannot write export chunk", e);
                return false;
            }
        }

        @JavascriptInterface
        public boolean finishDownload(String token, String mimeType) {
            File file = pending.remove(token);
            if (file == null) return false;
            String[] parts = token.split("\\|", 2);
            String name = parts.length > 1 ? parts[1] : "SQMOTION-export.bin";
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, name);
                values.put(MediaStore.Downloads.MIME_TYPE, (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SQMOTION");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri target = getContentResolver().insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values);
                if (target == null) throw new IllegalStateException("Could not create download file");
                try (InputStream in = new BufferedInputStream(new FileInputStream(file));
                     OutputStream out = new BufferedOutputStream(getContentResolver().openOutputStream(target, "w"))) {
                    byte[] buffer = new byte[256 * 1024];
                    int count;
                    while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
                }
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(target, ready, null, null);
                file.delete();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "حُفظ الملف في Downloads / SQMOTION", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                Log.e(TAG, "Cannot save export", e);
                file.delete();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "فشل حفظ التصدير: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }

        @JavascriptInterface
        public void cancelDownload(String token) {
            File file = pending.remove(token);
            if (file != null) file.delete();
        }
    }
}
