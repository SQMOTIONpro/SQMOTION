# SQMOTION — Arabic localization patch

This local change adds Arabic (`ar`) to the language selector, applies RTL-aware localization, and extends Arabic coverage to the home page, project creation, editor controls, layer actions, transformation controls, blend/masking panels, effect-browser categories, dynamic counts, and accessibility/title hints.

Validation performed:
- All mapped source strings resolve to keys in the Arabic dictionary.
- All 16 executable inline JavaScript blocks pass `node --check`.
- `git diff --check` passes.
- Main page, project creation, editor, layer inspector, blend/masking panel, and transform controls were inspected in the browser during implementation.

Official product/effect names (for example SQMOTION, Alight Motion, Gaussian Blur, Particular), file formats, keyboard shortcuts, dimensions, and technical identifiers remain in their established form. User-created layer/project names are intentionally not translated.

This is a local source modification only; it has not been pushed or submitted upstream.
