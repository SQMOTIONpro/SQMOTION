import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const models = new Map();
const pendingLoads = new Map();
let renderer = null, pmrem = null, environment = null;
const loadBytes = b64 => { const raw = atob(b64), out = new Uint8Array(raw.length); for (let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i); return out; };
const toDataURL = (bytes, mime='application/octet-stream') => {
  let binary=''; for(let i=0;i<bytes.length;i+=0x8000) binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));
  return `data:${mime};base64,${btoa(binary)}`;
};
const mimeFor = name => ({png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',ktx2:'image/ktx2'}[(String(name).split('.').pop()||'').toLowerCase()]||'application/octet-stream');
function initRenderer(){
  if(renderer)return;
  const canvas=document.createElement('canvas');
  renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.NoToneMapping; renderer.setClearColor(0x000000,0);
  pmrem=new THREE.PMREMGenerator(renderer); environment=pmrem.fromScene(new RoomEnvironment(),0.04).texture;
}
function asGLTFJSON(entry,files){
  const text=new TextDecoder().decode(entry),json=JSON.parse(text),dir=entry.__name.split(/[\\/]/);dir.pop();
  const get=(uri)=>{const clean=decodeURIComponent(String(uri).split(/[?#]/)[0]);const parts=dir.slice();for(const x of clean.split(/[\\/]/)){if(!x||x==='.')continue;if(x==='..')parts.pop();else parts.push(x)}return files[parts.join('/')];};
  for(const b of json.buffers||[]) if(b.uri&&!/^data:/i.test(b.uri)){const found=get(b.uri);if(!found)throw new Error(`ملف BIN المرافق غير موجود: ${b.uri}`);b.uri=toDataURL(found,'application/octet-stream');}
  for(const image of json.images||[]) if(image.uri&&!/^data:/i.test(image.uri)){const found=get(image.uri);if(!found)throw new Error(`صورة الخامة غير موجودة داخل ZIP: ${image.uri}`);image.uri=toDataURL(found,mimeFor(image.uri));}
  return JSON.stringify(json);
}
function decodePackage(pkg,entryPath){
  if(pkg.kind==='zip'){
    const zip=loadBytes(pkg.data), files=window.fflate.unzipSync(zip); const model=files[entryPath];
    if(!model)throw new Error('تعذّر العثور على ملف المجسم داخل ZIP.');
    if(/\.gltf$/i.test(entryPath)){model.__name=entryPath;return{kind:'gltf',data:asGLTFJSON(model,files)};}
    return{kind:String(entryPath).split('.').pop().toLowerCase(),data:model,files,entryPath};
  }
  const data=loadBytes(pkg.data),kind=pkg.kind;
  if(kind==='gltf')return{kind,data:new TextDecoder().decode(data)};
  return{kind,data};
}
function parseThree(decoded){
  return new Promise((resolve,reject)=>{
    if(decoded.kind==='gltf'||decoded.kind==='glb'){
      const loader=new GLTFLoader();
      const input=decoded.kind==='glb'?decoded.data.buffer.slice(decoded.data.byteOffset,decoded.data.byteOffset+decoded.data.byteLength):decoded.data;
      loader.parse(input,'',g=>resolve({scene:g.scene,animations:g.animations||[],gltf:g}),reject);return;
    }
    if(decoded.kind==='obj'){
      try{const text=new TextDecoder().decode(decoded.data),manager=new THREE.LoadingManager();let blobUrls=[];manager.setURLModifier(url=>{if(/^(data:|blob:)/i.test(url))return url;const parts=String(url).split(/[?#]/)[0].replace(/^\/+/, '').split('/'),stack=[];for(const part of parts){if(part==='..')stack.pop();else if(part&&part!=='.')stack.push(decodeURIComponent(part))}const found=decoded.files?.[stack.join('/')];if(!found)return url;const blob=URL.createObjectURL(new Blob([found],{type:mimeFor(stack.join('/'))}));blobUrls.push(blob);return blob});let scene;const libraries=[...text.matchAll(/^\s*mtllib\s+(.+)$/gmi)].flatMap(m=>m[1].trim().split(/\s+/));if(libraries.length&&decoded.files){const library=libraries[0],base=decoded.entryPath.split(/[\\/]/);base.pop();const path=[...base,library].filter(Boolean).join('/'),mtlBytes=decoded.files[path]||decoded.files[library];if(mtlBytes){const mtlText=new TextDecoder().decode(mtlBytes),mtlPath=path.split('/');mtlPath.pop();const materials=new MTLLoader(manager).parse(mtlText,mtlPath.length?mtlPath.join('/')+'/':'');materials.preload();const loader=new OBJLoader(manager);loader.setMaterials(materials);scene=loader.parse(text)}}if(!scene)scene=new OBJLoader(manager).parse(text);resolve({scene,animations:[],gltf:null,blobUrls});}catch(e){reject(e)}return;
    }
    if(decoded.kind==='stl'){
      try{const geometry=new STLLoader().parse(decoded.data.buffer.slice(decoded.data.byteOffset,decoded.data.byteOffset+decoded.data.byteLength));geometry.computeVertexNormals();const mat=new THREE.MeshStandardMaterial({color:0xd7dce7,roughness:.42,metalness:.08});const scene=new THREE.Group();scene.add(new THREE.Mesh(geometry,mat));resolve({scene,animations:[],gltf:null});}catch(e){reject(e)}return;
    }
    reject(new Error('صيغة العرض الكامل غير مدعومة داخل هذا النموذج.'));
  });
}
function fitCamera(record){
  const box=new THREE.Box3().setFromObject(record.scene);if(box.isEmpty())box.setFromCenterAndSize(new THREE.Vector3(),new THREE.Vector3(2,2,2));
  const center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3()),radius=Math.max(size.x,size.y,size.z)*.68||1;
  record.center.copy(center);record.camera.position.set(center.x+radius*1.7,center.y+radius*1.1,center.z+radius*2.7);record.camera.near=Math.max(.001,radius/1000);record.camera.far=radius*100;record.camera.lookAt(center);record.camera.updateProjectionMatrix();
}
async function loadLayer(id,pkg,entryPath){
  if(models.has(id))return{bones:boneInfo(id),animations:models.get(id).clips.map(a=>a.name),hasRig:models.get(id).bones.length>0};
  if(pendingLoads.has(id))return pendingLoads.get(id);
  const task=(async()=>{initRenderer();
  const decoded=decodePackage(pkg,entryPath),loaded=await parseThree(decoded);const scene=new THREE.Scene();scene.background=null;scene.environment=environment;scene.environmentIntensity=1.15;
  scene.add(new THREE.HemisphereLight(0xffffff,0x414b5d,1.65));const key=new THREE.DirectionalLight(0xffffff,2.1);key.position.set(3,5,6);scene.add(key);const fill=new THREE.DirectionalLight(0xc5dcff,.65);fill.position.set(-5,1,-4);scene.add(fill);scene.add(loaded.scene);
  const camera=new THREE.PerspectiveCamera(34,1,.01,10000);const record={id,scene:loaded.scene,camera,wrapper:scene,clips:loaded.animations,center:new THREE.Vector3(),bones:[],mixer:null,actions:[],size:512,canvas:document.createElement('canvas')};
  loaded.scene.traverse(o=>{if(o.isBone)record.bones.push(o);if(o.isMesh||o.isSkinnedMesh){o.frustumCulled=false;for(const m of (Array.isArray(o.material)?o.material:[o.material]))if(m){m.needsUpdate=true}}});
  if(loaded.animations.length){record.mixer=new THREE.AnimationMixer(loaded.scene);record.actions=loaded.animations.map(clip=>record.mixer.clipAction(clip));}
  fitCamera(record);models.set(id,record);return{bones:record.bones.map((b,i)=>({name:b.name||`Bone ${i+1}`,index:i})),animations:loaded.animations.map(a=>a.name),hasRig:record.bones.length>0};})();pendingLoads.set(id,task);try{return await task}finally{pendingLoads.delete(id)}
}
function boneSegment(bone){bone.updateWorldMatrix(true,false);const start=bone.getWorldPosition(new THREE.Vector3());let child=bone.children.find(c=>c.isBone);const end=child?child.getWorldPosition(new THREE.Vector3()):start.clone().add(new THREE.Vector3(0,.03,0));return{start,end};}
function autoRig(id,kind='humanoid'){
  const r=models.get(id);if(!r)throw new Error('المجسم غير محمّل.');if(r.bones.length)return{hasRig:true,bones:r.bones.map((b,i)=>({name:b.name||`Bone ${i+1}`,index:i}))};
  const root=r.scene;root.updateMatrixWorld(true);const box=new THREE.Box3().setFromObject(root);if(box.isEmpty())throw new Error('تعذّر تحديد شكل المجسم لإنشاء Rig.');const size=box.getSize(new THREE.Vector3()),c=box.getCenter(new THREE.Vector3());
  const H=Math.max(size.y,size.x,size.z),W=Math.max(size.x,.12*H),D=Math.max(size.z,.12*H);if(H<1e-5)throw new Error('أبعاد المجسم غير مناسبة للـRig التلقائي.');
  const p=(x,y,z)=>new THREE.Vector3(c.x+x*W,c.y+(y-.5)*H,c.z+z*D),bones=[],segments=[];
  const add=(name,a,b,parent=null)=>{const bone=new THREE.Bone();bone.name=name;bone.position.copy(parent?parent.worldEndpoint.clone().multiplyScalar(1):a);if(parent){bone.position.copy(a).sub(parent.worldEndpoint);parent.bone.add(bone)}else root.add(bone);bone.userData.sqmBone=true;bone.worldEndpoint=b.clone();const item={bone,a:a.clone(),b:b.clone(),parent,worldEndpoint:b.clone()};bones.push(bone);segments.push(item);return item};
  const pelvis=add('hips',p(0,.49,0),p(0,.58,0));
  if(kind==='quadruped'){
    const spine=add('spine',p(0,.53,-.12),p(0,.56,.14),pelvis);const neck=add('neck',p(0,.56,.14),p(0,.58,.31),spine);add('head',p(0,.58,.31),p(0,.60,.46),neck);add('tail',p(0,.54,-.12),p(0,.52,-.44),spine);
    for(const [label,x,z] of [['frontL',-.28,.16],['frontR',.28,.16],['backL',-.25,-.2],['backR',.25,-.2]]){const hip=p(x,.51,z),knee=p(x*1.05,.26,z+(z>0?.04:-.04)),foot=p(x*1.1,.04,z+(z>0?.07:-.07));const a=add(label+'UpperLeg',hip,knee,z>0?spine:pelvis);add(label+'LowerLeg',knee,foot,a)}
  }else{
    const spine=add('spine',p(0,.53,0),p(0,.70,0),pelvis);const chest=add('chest',p(0,.70,0),p(0,.79,0),spine);const neck=add('neck',p(0,.79,0),p(0,.86,0),chest);add('head',p(0,.86,0),p(0,.99,0),neck);
    for(const [side,x] of [['L',-.5],['R',.5]]){const shoulder=p(x*.42,.77,0),elbow=p(x*.78,.65,0),wrist=p(x,.53,0),s=add('upperArm'+side,shoulder,elbow,chest);const e=add('forearm'+side,elbow,wrist,s);add('hand'+side,wrist,p(x*1.08,.50,0),e);const hip=p(x*.18,.49,0),knee=p(x*.22,.27,0),ankle=p(x*.23,.04,0),leg=add('upperLeg'+side,hip,knee,pelvis);add('lowerLeg'+side,knee,ankle,leg)}
  }
  root.updateMatrixWorld(true);
  const all=[];root.traverse(o=>{if(o.isMesh&&!o.isSkinnedMesh)all.push(o)});
  const inverseRoot=root.matrixWorld.clone().invert();
  for(const mesh of all){const old=mesh.geometry,geo=old.clone();geo.applyMatrix4(inverseRoot.multiply(mesh.matrixWorld));inverseRoot.copy(root.matrixWorld).invert();
    const pos=geo.getAttribute('position'),skinI=new Uint16Array(pos.count*4),skinW=new Float32Array(pos.count*4);
    for(let v=0;v<pos.count;v++){const point=new THREE.Vector3().fromBufferAttribute(pos,v),nearest=segments.map((seg,i)=>{const ab=seg.b.clone().sub(seg.a),den=ab.lengthSq()||1,t=THREE.MathUtils.clamp(point.clone().sub(seg.a).dot(ab)/den,0,1),q=seg.a.clone().addScaledVector(ab,t);return{i,d:point.distanceTo(q)+1e-6}}).sort((a,b)=>a.d-b.d).slice(0,4);let sum=0;nearest.forEach(x=>sum+=1/(x.d*x.d));nearest.forEach((x,j)=>{skinI[v*4+j]=x.i;skinW[v*4+j]=(1/(x.d*x.d))/sum})}
    geo.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(skinI,4));geo.setAttribute('skinWeight',new THREE.Float32BufferAttribute(skinW,4));
    const skinned=new THREE.SkinnedMesh(geo,mesh.material);skinned.name=mesh.name;mesh.parent.add(skinned);mesh.parent.remove(mesh);skinned.bind(new THREE.Skeleton(bones),root.matrixWorld);skinned.normalizeSkinWeights();
  }
  r.bones=bones;r.scene.updateMatrixWorld(true);r.autoRigType=kind;return{hasRig:true,autoRig:true,bones:bones.map((b,i)=>({name:b.name,index:i}))};
}
function applyPose(r,pose={}){for(const b of r.bones){const value=pose[b.name];if(Array.isArray(value)){b.rotation.set(THREE.MathUtils.degToRad(+value[0]||0),THREE.MathUtils.degToRad(+value[1]||0),THREE.MathUtils.degToRad(+value[2]||0),'XYZ')}}}
function renderCanvas(id,pose={},width=512,height=512,time=0,animationIndex=-1){
  const r=models.get(id);if(!r)return null;initRenderer();applyPose(r,pose);if(r.mixer){for(let i=0;i<r.actions.length;i++)if(i===animationIndex)r.actions[i].play();else r.actions[i].stop();r.mixer.setTime(Math.max(0,time));}
  r.canvas.width=Math.max(128,width|0);r.canvas.height=Math.max(128,height|0);renderer.setSize(r.canvas.width,r.canvas.height,false);r.camera.aspect=r.canvas.width/r.canvas.height;fitCamera(r);r.camera.updateProjectionMatrix();renderer.render(r.wrapper,r.camera);const ctx=r.canvas.getContext('2d');ctx.clearRect(0,0,r.canvas.width,r.canvas.height);ctx.drawImage(renderer.domElement,0,0,r.canvas.width,r.canvas.height);return r.canvas;
}
function boneInfo(id){const r=models.get(id);return r?r.bones.map((b,i)=>({name:b.name||`Bone ${i+1}`,index:i})):[]}
function openPosePanel(id,layer){
  const r=models.get(id);if(!r)throw new Error('المجسم لا يزال قيد التحميل.');document.getElementById('sqmRigPanel')?.remove();const box=document.createElement('div');box.id='sqmRigPanel';box.dir='rtl';box.style.cssText='position:fixed;z-index:2147483001;inset:6% 5%;max-width:620px;margin:auto;padding:18px;border-radius:18px;background:#151b29;color:#f4f7ff;border:1px solid #50617a;box-shadow:0 15px 60px #000b;font:14px system-ui;overflow:auto';
  const title=document.createElement('div');title.style.cssText='display:flex;justify-content:space-between;align-items:center;font-size:18px;font-weight:700;margin-bottom:12px';title.innerHTML='<span>Rig وتحريك الأطراف</span>';const close=document.createElement('button');close.textContent='إغلاق';close.onclick=()=>box.remove();title.appendChild(close);box.appendChild(title);
  if(r.clips.length){const animLabel=document.createElement('label');animLabel.textContent='حركة مرفقة: ';const anim=document.createElement('select');anim.innerHTML='<option value="-1">بدون حركة · وضع يدوي</option>'+r.clips.map((clip,i)=>`<option value="${i}">${clip.name||'حركة '+(i+1)}</option>`).join('');anim.value=String(layer.meshAnimationIndex??-1);anim.onchange=()=>{layer.meshAnimationIndex=+anim.value};animLabel.appendChild(anim);box.appendChild(animLabel)}
  if(!r.bones.length){const note=document.createElement('p');note.textContent='لم يُعثر على عظام. اختر محاولة Rig تلقائي تجريبية:';box.appendChild(note);const select=document.createElement('select');select.innerHTML='<option value="humanoid">شخصية بشرية / ثنائية الأرجل</option><option value="quadruped">حيوان رباعي الأرجل</option>';box.appendChild(select);const auto=document.createElement('button');auto.textContent='إنشاء Rig تلقائي تجريبي';auto.onclick=()=>{try{const result=autoRig(id,select.value);layer.meshAutoRigType=select.value;layer.meshBonePose={};drawBoneControls(box,id,layer,result.bones);auto.remove();note.textContent='تم إنشاء Rig تقريبي؛ قد تحتاج النتيجة إلى تعديل.'}catch(e){note.textContent='تعذر إنشاء Rig: '+e.message}};box.appendChild(auto)}else drawBoneControls(box,id,layer,boneInfo(id));document.body.appendChild(box);
}
function drawBoneControls(box,id,layer,bones){const holder=document.createElement('div');holder.style.cssText='display:grid;gap:8px;max-height:70vh;overflow:auto;margin-top:14px';for(const bone of bones){const row=document.createElement('div');row.style.cssText='padding:9px;border-radius:10px;background:#202a3c';const label=document.createElement('b');label.textContent=bone.name;row.appendChild(label);for(let axis=0;axis<3;axis++){const key=['x','y','z'][axis],control=document.createElement('label');control.style.cssText='display:grid;grid-template-columns:24px 1fr 42px;gap:8px;align-items:center;margin-top:6px';const span=document.createElement('span');span.textContent=key.toUpperCase();const range=document.createElement('input');range.type='range';range.min='-90';range.max='90';range.step='1';range.value=layer.meshBonePose?.[bone.name]?.[axis]||0;const number=document.createElement('span');number.textContent=range.value+'°';range.oninput=()=>{const pose=layer.meshBonePose||(layer.meshBonePose={});const value=pose[bone.name]||(pose[bone.name]=[0,0,0]);value[axis]=+range.value;number.textContent=range.value+'°';applyPose(models.get(id),pose)};control.append(span,range,number);row.appendChild(control)}holder.appendChild(row)}box.appendChild(holder)}
window.SQMOTIONThree={loadLayer,renderCanvas,autoRig,boneInfo,openPosePanel,hasLayer:id=>models.has(id),dispose:id=>{models.delete(id);pendingLoads.delete(id)}};
